function Content() {
  return (
    <>
      <div className="row mt-4">
        <div class="col-md-4">
          <div class="personal-details">
            <h3>Details</h3>
            <p>DHA, Lahore, 54000, Pakistan</p>
            <p>03152110630</p>
            <p>omarabobakar21@gmail.com</p>
            <p>Nationality: Pakistani</p>
            <p>Date/Place of Birth: 21-Oct-2002, Lahore</p>
            <p>
              <a href="https://umarseoservices.blogspot.com/">Blogger</a> |{" "}
              <a href="https://www.linkedin.com/in/omar-abo-bakar-2984502b3/">
                LinkedIn
              </a>
            </p>
          </div>
          <div class="skills mt-4">
            <h3>Skills</h3>
            <ul>
              <li>SEO</li>
              <li>Digital Marketing</li>
              <li>UI Designer</li>
              <li>Keyword Research</li>
              <li>Wordpress</li>
            </ul>
          </div>
          <div class="languages mt-4">
            <h3>Languages</h3>
            <ul>
              <li>English</li>
              <li>Urdu</li>
            </ul>
          </div>
          <div class="hobbies mt-4">
            <h3>Hobbies</h3>
            <ul>
              <li>Photography</li>
              <li>Cricket</li>
              <li>Gym</li>
            </ul>
          </div>
        </div>

        <div className="col-md-8">
          <p>
            As a dedicated student with a strong academic record, I excel in
            multitasking and collaboration. Passionate about technology, I
            specialize in UI Design, Wordpress, Coding and SEO optimization to
            create compelling online experiences.
          </p>

          <h3>Education</h3>
          <p><strong>Matric, Garrison, Lahore</strong><br />June 2016 — June 2018<br />Science, Marks 87%</p>
          <p><strong>Intermediate, Garrison, Lahore</strong><br />September 2018 — June 2020<br />Pre-Engineering, Marks 72%</p>
                <p><strong>Bachelor's, UMT, Lahore</strong><br />October 2020 — Present</p>
                <h3>Courses</h3>
                <p><strong>Web Technology, UMT</strong><br />June 2021 — September 2021</p>
                <p><strong>Numerical Analysis, UMT</strong><br />October 2021 — February 2022</p>
                <p><strong>Digital Marketing, NCA</strong><br />June 2022 — September 2022</p>
                <h3>Internships</h3>
                <p><strong>UI Designer, NCA, Lahore</strong><br />June 2022 — September 2022</p>
                <p><strong>Digital Marketing, Spice n Spirit, London</strong><br />June 2023 — October 2023</p>
                <h3>Employment History</h3>
                <p><strong>UI Designer, NCA, Lahore</strong><br />June 2022 — September 2022</p>
                <p><strong>Digital Marketing, Spice n Spirit, London</strong><br />June 2023 — October 2023</p>
        </div>
      </div>
    </>
  );
}

export default Content;
