import omar from "/omar.jpg"
function Header() {

  return (
    <>
      <div className="header bg-light-blue text-center p-4">
            <img src={omar} class="img-fluid rounded mb-3" alt="Omar Abobakar" />
            <h2>Omar Abobakar</h2>
            <p>SEO Specialist</p>
        </div>
    </>
  )
}

export default Header
